# Changelog

## v1.0.2
- Added new emojis.
- Removed invalid request emojis.

## v1.0.1
- Refreshed the user interface.
- Updated emojis to animated versions.
- Optimized the source code.
